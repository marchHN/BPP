Ops.Utils package
=================

Submodules
----------

Ops.Utils.Calculadora module
----------------------------

.. automodule:: Ops.Utils.Calculadora
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: Ops.Utils
   :members:
   :undoc-members:
   :show-inheritance:
