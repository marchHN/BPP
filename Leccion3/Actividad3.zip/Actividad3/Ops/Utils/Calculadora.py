class Calculadora:
    """Calculadora
    
    Atributos
    -----------
    num1:
        primer operando
    num2:
        segundo operando
    
    Metodos
    -----------
    Sumar:
        Suma los operandos num1 y num2
    Restar:
        Resta los operandos num1 y num2
    Multiplicar:
        Multiplica los operandos num1 y num2
    Dividir:
        Divide los operandos num1 y num2
    
    Ejemplos
    -----------
    >>> import Calculadora
    >>> ot = Calculadora(num1,num2)
    >>> restultado_suma = ot.Sumar()
    """
    def __init__(self,num1,num2):
        self.num1 = num1
        self.num2 = num2
    
    def Sumar(self):
        """
        Metodo Sumar. Suma num1 y num2.
        Inputs
        --------
            self.num1
            self.num2
        Outputs
        --------
            res: resultado de la operacion
        """
        print(self.num1 + self.num2)
        return self.num1 + self.num2
    
    def Restar(self):
        """
        Metodo Restar. Resta num1 y num2.
        Inputs
        --------
            self.num1
            self.num2
        Outputs
        --------
            res: resultado de la operacion
        """
        print(self.num1 - self.num2)
        return self.num1 - self.num2
    
    def Multiplicar(self):
        """
        Metodo Multiplicar. Multiplica num1 y num2.
        Inputs
        --------
            self.num1
            self.num2
        Outputs
        --------
            res: resultado de la operacion
        """
        print(self.num1 * self.num2)
        return self.num1 * self.num2
    
    def Dividir(self):
        """
        Metodo Dividir. Divide num1 y num2.
        Inputs
        --------
            self.num1
            self.num2
        Outputs
        --------
            res: resultado de la operacion
        """
        if(self.num2 > 0):
            print(self.num1 / self.num2)
            return self.num1 / self.num2
        else:
            print("Error! no se puede dividir entre 0")
            return "Error"  