from Utils.Calculadora import Calculadora

if __name__ == "__main__":
    m = Calculadora(5,6)
    m.Sumar()